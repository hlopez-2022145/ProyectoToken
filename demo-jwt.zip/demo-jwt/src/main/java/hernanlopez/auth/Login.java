package hernanlopez.auth;


public class Login {

    String username;
    String password;
}
