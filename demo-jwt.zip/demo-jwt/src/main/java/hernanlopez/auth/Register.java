package hernanlopez.auth;

public class Register {
    String token;
}
